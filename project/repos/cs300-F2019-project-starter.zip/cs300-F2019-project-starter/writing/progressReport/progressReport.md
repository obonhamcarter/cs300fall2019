## Names of group members:
## Date: 4 Nov 2019

# Proposal Document:

Please place the progress report document material (text and graphics) here.

![Logo](graphics/allegheny.png)

(Have you remembered to add the names of your group members above?)
