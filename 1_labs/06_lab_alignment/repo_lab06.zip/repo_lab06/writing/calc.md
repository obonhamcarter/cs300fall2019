#### Date: 7 Oct 2019
#### Local Alignment calculations
#### Please place your calculations for each cell (labeled by a letter) in the relevant row and column.

---

Cell     |     Gap calc     |     Match     |     Mismatch     |     Max value

a)       |                  |               |                  |

b)       |                  |               |                  |

c)       |                  |               |                  |

d)       |                  |               |                  |

e)       |                  |               |                  |

f)       |                  |               |                  |
