#### Name:
#### Date:
#### What this is: Questions in blue from lab06's assignment sheet.

#### Part 1.

1. How similar were the two sequences (s1.txt and (s2.txt) which you applied to the included alignment program written in Python3?

2. Are the two sequences closely related to each other?

3. What proof do you have to suggest such a claim? 




#### Part 2
1. How much similarity exists between each of the sequences to the others?	

2. Based on your results (which are too few to provide a comprehensive study), do you believe there is evidence that human adaptation is occurring in H5N1 viruses that might merit concern about human-to-human transmission in the near future?

3. Statistics: What were the numbers of Lengths, Similarities, Gaps and Scores for each of your alignment tasks? 




(did you remember to add your name to this Markdown file?) 
