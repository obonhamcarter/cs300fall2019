# Name:
# Date: 16 Sept 2019


#### Reflections

Please respond to the following questions using about 100 words.

1: How did you approach the debugging of your program?


(your response here)
___

2: How did you uncover the logical bugs (i.e., bugs that permitted the program to run, although the output was incorrect)?


(your response here)
___
