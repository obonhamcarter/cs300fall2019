# Date: 30 Sept 2019
Your code from lab3 can be copied for use in this lab. Please use your own code for this lab.
The source code file is to be called: mutDetect_ii.py
