#### Date: 2 Sept 2019
#### Lab01

##### Instructions
In this practical assignment, you are to add your reflections concerning the installation of software on your personal machine. In particular, the instructor is interested to know your reflective thoughts on the following issues.

+ Which software packages (names and versions) you installed on your machine.
+ Which challenges you encountered during the installation and testing to ensure a working configuration if the softwares.
+ The methods and approaches to solutions you used to overcome the challenge.

Your reflection should be about a page and contain meaningful language, complete sentences and a professional voice. Please use markdown language to format your reflection piece.

Please write below this line to address the above-mentioned points.
___
1) Which software packages (names and versions) you installed on your machine.


___
2) Which challenges you encountered during the installation and testing to ensure a working configuration if the softwares.


___
3) The methods and approaches to solutions you used to overcome the challenge.
