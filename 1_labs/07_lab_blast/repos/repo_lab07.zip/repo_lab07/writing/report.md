#### Name:
#### Date: 21 October 2019

#### Part1
### Discussion of Two Virulence factors.





#### Results and Conclusions

#### Part2

After trying out each of the online tools for alignment, as discussed in the assignment, name the strengths of each.


#### How do they contrast?

#### Were you able to find any additional tools for alignment tasks?
